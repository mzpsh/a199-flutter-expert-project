# a199-flutter-expert-project
## Build Status / CI
[![Codemagic build status](https://api.codemagic.io/apps/627274348f3a1f1260822355/627274348f3a1f1260822354/status_badge.svg)](https://codemagic.io/apps/627274348f3a1f1260822355/627274348f3a1f1260822354/latest_build)

![](screenshots/codemagic.png)

## Analytics and Crashlytics
![](screenshots/analytics.png)
![](screenshots/crashlytics.png)
