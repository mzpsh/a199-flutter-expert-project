const tvseries_detail_json = '''
{
	"id": 69,
	"poster_path": "poster_path",
	"name": "name",
	"number_of_seasons": 6,
	"number_of_episodes": 6,
	"vote_average": 4.20,
	"overview": "overview"
}
''';
