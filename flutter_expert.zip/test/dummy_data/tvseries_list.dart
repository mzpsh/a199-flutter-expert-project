const tvseries_list_json = '''
{
  "page": 1,
  "results": [
    {
      "poster_path": "posterPath",
      "id": 69,
      "vote_average": 5,
      "overview": "overview",
      "name": "name"
    }
  ],
  "total_pages": 1,
  "total_results": 10
}
''';
