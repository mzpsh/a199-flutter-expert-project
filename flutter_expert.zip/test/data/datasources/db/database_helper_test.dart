import 'package:flutter_test/flutter_test.dart';

void main() {
  test('able to return an instance of DatabaseHelper', () async {
    /// not supported
    /// check https://github.com/tekartik/sqflite/blob/master/sqflite/doc/testing.md
    // WidgetsFlutterBinding.ensureInitialized();

    // final dbHelper = DatabaseHelper();
    // final db = await dbHelper.database;
    // // ignore: unnecessary_type_check
    // expect(db is DatabaseHelper, true);
  });
}
