import 'package:ditonton/data/datasources/db/sembast_database_helper.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sembast/sembast.dart';

void main() {
  test('able to return an instance of Database', () async {
    final dbHelper = SembastDatabaseHelper();

    final db = await dbHelper.database;
    // ignore: unnecessary_type_check
    expect(db is Database, true);
  });
}
